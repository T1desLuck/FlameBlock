#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Патч №6 — по результатам исследования на 6 тестовых сайтах (obfusgated.com,
mobileproxy.space, getblockify.com, superadblocktest.com, paileactivist.github.io,
adblocktester.pages.dev). Только ДОБАВЛЯЕТ, ничего не удаляя и не трогая.

Часть доменов из исследования СОЗНАТЕЛЬНО не добавлена — см. SKIP_SHARED_INFRA:
это общая инфраструктура (видео YouTube, вход через соцсети, видео-плеер
JWPlayer/Vimeo/Brightcove как ПО, а не реклама), блокировка которой сломала бы
обычную работу сайтов, а не только рекламу. Это тот же принцип, что и раньше.
"""

import json
import os

BASE = os.path.dirname(os.path.abspath(__file__))

SKIP_SHARED_INFRA = {
    "s.youtube.com", "redirector.googlevideo.com", "youtubei.googleapis.com",
    "graph.facebook.com", "graph.instagram.com", "i.instagram.com", "www.facebook.com",
    "widgets.pinterest.com", "is.com",
    # видео-платформы/плееры как ПО, а не рекламные SDK — блокировка ломает
    # сам плеер/трансляцию, а не только рекламу в нём
    "f.vimeocdn.com", "cdn.jwplayer.com", "api.bcovlive.io",
}

ADS_NEW = [
    "mads.amazon.com", "adsapi.snapchat.com", "ads.google.com", "ads.facebook.com",
    "advertising.twitter.com", "ads-dev.pinterest.com", "ads.reddit.com",
    "adservice.google.de", "vid.springserve.com", "sync.springserve.com",
    "cdn.springserve.com", "ad.tritondigital.com", "tritondigital.com",
    "adx.mintegral.com", "share.mintegral.com", "app.link", "2giga.link",
]

TRACKERS_NEW = [
    # аналитика / продуктовая телеметрия
    "cdn.piwik.pro", "piwik.pro", "cdn.pendo.io", "app.pendo.io", "pendo.io",
    "tags.tiqcdn.com", "ce.lijit.com", "i.liadm.com", "unagi-na.amazon.com",
    # мониторинг ошибок (опциональные SDK, отключение не ломает сайт)
    "cdn.ravenjs.com", "trackjs.com", "api.raygun.io", "usage.trackjs.com",
    "cdn.raygun.io", "js.honeybadger.io", "api.honeybadger.io", "raygun.io",
    # криптомайнеры — не реклама, но однозначно нежелательны
    "coinhive.com", "coin-hive.com", "ppoi.org", "cryptoloot.org", "hashing.win",
    "cpu.js.org", "fastpool.xyz", "afminer.com", "hashforcash.us", "webminerpool.com",
    # OEM-телеметрия
    "oca.telemetry.microsoft.com", "firebaselogging.googleapis.com",
    "clientservices.googleapis.com", "browser.events.data.msn.com",
    "data.mistat.intl.xiaomi.com", "tracking.intl.miui.com", "tracking.india.miui.com",
    "business.samsungusa.com", "securemetrics.apple.com",
    # cookie-баннеры / CMP
    "cookies-data.onetrust.io", "c.betrad.com", "ats.rlcdn.com",
    # A/B-тестирование и feature-flag сервисы (у SDK есть безопасный fallback
    # по умолчанию, отключение не ломает сайт — просто не переключает флаг)
    "sdk.split.io", "cdn.split.io", "streaming.split.io", "events.split.io",
    "vwo.com", "cdn-eu.configcat.com", "cdn.configcat.com", "api.flagsmith.com",
    "edge.api.flagsmith.com", "data.kameleoon.io", "stream.launchdarkly.com",
    "mobile.launchdarkly.com", "app.launchdarkly.com", "clientstream.launchdarkly.com",
    # email-трекинг (пиксели/клик-редиректы, не сама доставка почты)
    "assets.mailerlite.com", "mailchimp.com", "click.mailerlite.com",
    "app.convertkit.com", "open.convertkit.com", "sibautomation.com",
    "pi.pardot.com", "clicks.aweber.com", "email.mailgun.net", "pixel.aweber.com",
    "mandrillapp.com", "sendgrid.net",
    # видео-аналитика (не сам плеер/CDN)
    "fresnel.vimeocdn.com",
    # разное из d3ward-подобных тестов
    "affiliationjs.s3.amazonaws.com", "sstats.adobe.com", "assets.adobedtm.com",
    "alb.reddit.com", "q.quora.com", "app.adjust.world", "cdn-settings.appsflyersdk.com",
    "sdk-events.inner-active.mobi", "cdn2.inner-active.mobi",
    "api.chartboost.com", "da.chartboost.com",
    "tradedoubler.com", "t.tradedoubler.com", "clk.tradedoubler.com", "imp.tradedoubler.com",
]


def load_rules(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def existing_domains(rules):
    return {r.get("condition", {}).get("urlFilter", "").strip("|^") for r in rules}


def append_domain_rules(path, new_domains, resource_types):
    rules = load_rules(path)
    have = existing_domains(rules)
    next_id = max((r["id"] for r in rules), default=0) + 1
    added = 0
    for d in new_domains:
        if d in SKIP_SHARED_INFRA or d in have:
            continue
        have.add(d)
        rules.append({
            "id": next_id, "priority": 1, "action": {"type": "block"},
            "condition": {"urlFilter": f"||{d}^", "resourceTypes": resource_types},
        })
        next_id += 1
        added += 1
    with open(path, "w", encoding="utf-8") as f:
        json.dump(rules, f, ensure_ascii=False, separators=(",", ":"))
    return len(rules), added


def append_generic_rules(path, patterns, resource_types):
    rules = load_rules(path)
    have = {r.get("condition", {}).get("urlFilter", "") for r in rules}
    next_id = max((r["id"] for r in rules), default=0) + 1
    added = 0
    for pat in patterns:
        if pat in have:
            continue
        have.add(pat)
        rules.append({
            "id": next_id, "priority": 1, "action": {"type": "block"},
            "condition": {"urlFilter": pat, "resourceTypes": resource_types},
        })
        next_id += 1
        added += 1
    with open(path, "w", encoding="utf-8") as f:
        json.dump(rules, f, ensure_ascii=False, separators=(",", ":"))
    return len(rules), added


ADS_TYPES = ["main_frame", "sub_frame", "script", "image", "xmlhttprequest",
             "media", "font", "object", "ping", "other", "websocket", "stylesheet"]
TRACKERS_TYPES = ["sub_frame", "script", "image", "xmlhttprequest", "ping", "other", "media", "websocket"]

ads_path = os.path.join(BASE, "rules", "ads.json")
trackers_path = os.path.join(BASE, "rules", "trackers.json")

# adblocktester.pages.dev: локальные скрипты-приманки advertisement.js / analytics.js
# не ловились — тот же класс проблемы, что чинили с pagead.js/ads.js: имя файла
# без привязки к домену (первого лица).
script_total, script_added = append_generic_rules(
    ads_path, ["advertisement.js", "analytics.js"], ["script"])

ads_total, ads_added = append_domain_rules(ads_path, ADS_NEW, ADS_TYPES)
trk_total, trk_added = append_domain_rules(trackers_path, TRACKERS_NEW, TRACKERS_TYPES)
aab_total = len(load_rules(os.path.join(BASE, "rules", "antiadblock.json")))

grand_total = ads_total + trk_total + aab_total
print(f"generic script-правила: +{script_added}")
print(f"ads.json:      +{ads_added:>4} доменов (из {len(ADS_NEW)}) -> итого {ads_total}")
print(f"trackers.json:  +{trk_added:>4} доменов (из {len(TRACKERS_NEW)}) -> итого {trk_total}")
print(f"пропущено намеренно (общая инфраструктура): {len(SKIP_SHARED_INFRA)}")
print(f"ВСЕГО ПРАВИЛ:    {grand_total} (лимит 30000)")
