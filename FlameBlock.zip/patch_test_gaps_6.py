#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Патч №7 — новый список доменов от пользователя. Только ДОБАВЛЯЕТ.

Часть доменов НЕ добавлена (SKIP_SHARED_INFRA) — это либо уже установленные
раньше исключения (общая инфраструктура видео/соцсетей), либо новые похожие
случаи:
  - t.co — собственный сокращатель ссылок Twitter/X: это не трекер на чужих
    сайтах, а механизм навигации ИЗ твитов — блокировка сломала бы переход по
    любой ссылке, опубликованной в твите, а не просто убрала бы рекламу.
  - redditmedia.com (без поддомена) — это CDN самого контента Reddit
    (картинки/видео в постах), а не только трекинг-пиксель. Точечный трекер
    events.redditmedia.com у нас уже заблокирован отдельно — его не трогаем.
"""

import json
import os

BASE = os.path.dirname(os.path.abspath(__file__))

SKIP_SHARED_INFRA = {
    "t.co", "redditmedia.com",
    "graph.facebook.com", "www.facebook.com", "widgets.pinterest.com",
    "f.vimeocdn.com", "cdn.jwplayer.com", "api.bcovlive.io",
}

ADS_NEW = [
    "staticxx.facebook.com", "platform.twitter.com", "syndication.twitter.com",
    "platform.instagram.com", "plus.google.com", "st-widget.s3.amazonaws.com",
    "vap.lijit.com", "ap.lijit.com", "net.rayjump.com", "setting.rayjump.com",
    "detect.rayjump.com", "i.l.inmobicdn.net",
    "pos.baidu.com", "cpro.baidu.com", "dup.baidustatic.com", "eclick.baidu.com",
    "media.adtimaserver.vn", "static.adtimaserver.vn", "vk-ads.com",
]

TRACKERS_NEW = [
    "browser-intake-us5-datadoghq.com", "log-config.samsungacr.com",
    "e.qq.com", "pingjs.qq.com", "wcs.naver.net", "rs.mail.ru",
]


def load_rules(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def existing_domains(rules):
    return {r.get("condition", {}).get("urlFilter", "").strip("|^") for r in rules}


def append_domain_rules(path, new_domains, resource_types):
    rules = load_rules(path)
    have = existing_domains(rules)
    next_id = max((r["id"] for r in rules), default=0) + 1
    added = 0
    for d in new_domains:
        if d in SKIP_SHARED_INFRA or d in have:
            continue
        have.add(d)
        rules.append({
            "id": next_id, "priority": 1, "action": {"type": "block"},
            "condition": {"urlFilter": f"||{d}^", "resourceTypes": resource_types},
        })
        next_id += 1
        added += 1
    with open(path, "w", encoding="utf-8") as f:
        json.dump(rules, f, ensure_ascii=False, separators=(",", ":"))
    return len(rules), added


ADS_TYPES = ["main_frame", "sub_frame", "script", "image", "xmlhttprequest",
             "media", "font", "object", "ping", "other", "websocket", "stylesheet"]
TRACKERS_TYPES = ["sub_frame", "script", "image", "xmlhttprequest", "ping", "other", "media", "websocket"]

ads_total, ads_added = append_domain_rules(os.path.join(BASE, "rules", "ads.json"), ADS_NEW, ADS_TYPES)
trk_total, trk_added = append_domain_rules(os.path.join(BASE, "rules", "trackers.json"), TRACKERS_NEW, TRACKERS_TYPES)
aab_total = len(load_rules(os.path.join(BASE, "rules", "antiadblock.json")))

grand_total = ads_total + trk_total + aab_total
print(f"ads.json:      +{ads_added:>4} доменов (из {len(ADS_NEW)}) -> итого {ads_total}")
print(f"trackers.json:  +{trk_added:>4} доменов (из {len(TRACKERS_NEW)}) -> итого {trk_total}")
print(f"пропущено намеренно: {len(SKIP_SHARED_INFRA)}")
print(f"ВСЕГО ПРАВИЛ:    {grand_total} (лимит 30000)")
